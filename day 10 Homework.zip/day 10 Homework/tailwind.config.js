/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./public/**/*.{html,js}"],
  theme: {
    screens:{
      sm:'480px',
      md:'768px',
      lg:'976px',
      xl:'1440px',
    },
    colors: {
      black: 'var(--black)',
      white: 'var(--white)',
      orange: 'var(--orange)',
      gray: 'var(--gray)',
      blue: 'var(--blue)',
      red: 'var(--red)',
    },
    fontFamily: {
      'Dancing-Scripts': 'var(--font-Dancing-Scripts)',
      'Lato': 'var(--font-Lato)',
      'Poppins': 'var(--font-Poppins)',
    },
    extend: {},
  },
  plugins: [],
}

